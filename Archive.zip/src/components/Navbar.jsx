import React from 'react';
import { Link } from 'react-router-dom';
import useFetchData from '../hooks/useFetchData';

function Navbar() {
  const [isLoading, , siteSettings] = useFetchData('/api/v1/site-settings');

  if (isLoading) return null;

  return (
    <nav className="bg-white shadow-lg fixed w-full z-50 top-0">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center py-3">
          {/* Logo and Title */}
          <div className="flex items-center">
            <img
              src={siteSettings?.data?.school_logo || '/default-logo.png'}
              alt="School Logo"
              className="h-12 w-12 mr-3 object-contain p-1 bg-white rounded-lg shadow-sm"
            />
            <div>
              <div className="text-xl font-bold text-blue-700 leading-tight">
                {siteSettings?.data?.school_name || 'School Name'}
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium"
            >
              Home
            </Link>
            <Link 
              to="/informasi" 
              className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium"
            >
              Informasi
            </Link>
            <Link 
              to="/agenda" 
              className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium"
            >
              Agenda
            </Link>
            <Link 
              to="/album" 
              className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium"
            >
              Gallery
            </Link>
          </div>

          {/* Login Button */}
          <div>
            <Link
              to="/login"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 font-medium shadow-sm hover:shadow-md"
            >
              Login
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar; 